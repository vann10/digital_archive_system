"use server";

import { revalidatePath } from "next/cache";
import { db } from "../../db";
import { jenisArsip, schemaConfig } from "../../db/schema";
import { eq, sql, like, and, asc } from "drizzle-orm";

/* =========================
   HELPERS
========================= */

function generateSafeTableName(name: string) {
  const cleanName = name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");

  return `arsip_${cleanName}`;
}

function generateColumnName(label: string) {
  return label
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "_");
}

/* =========================
   GET LIST
========================= */

export async function getJenisArsipList(search?: string) {
  try {
    const filters = [];

    if (search) {
      filters.push(like(jenisArsip.namaJenis, `%${search}%`));
    }

    const list = await db
      .select({
        id: jenisArsip.id,
        namaJenis: jenisArsip.namaJenis,
        namaTabel: jenisArsip.namaTabel,
        prefixKode: jenisArsip.prefixKode,
        deskripsi: jenisArsip.deskripsi,
        createdAt: jenisArsip.createdAt,
      })
      .from(jenisArsip)
      .where(and(...filters));

    // hitung jumlah data tiap tabel
    const result = [];

    for (const item of list) {
      let totalData = 0;

      try {
        const countResult = db.get(
          sql.raw(`SELECT COUNT(*) as total FROM ${item.namaTabel}`)
        ) as any;

        totalData = countResult?.total ?? 0;
      } catch {
        totalData = 0;
      }

      result.push({
        ...item,
        jumlahData: totalData,
      });
    }

    return result;

  } catch (error) {
    console.error("Gagal mengambil daftar jenis arsip:", error);
    return [];
  }
}


/* =========================
   GET DETAIL
========================= */

export async function getJenisArsipDetail(id: number) {
  try {
    const jenis = await db.query.jenisArsip.findFirst({
      where: eq(jenisArsip.id, id),
    });

    if (!jenis) return { jenis: null, schema: [] };

    const schema = await db
      .select()
      .from(schemaConfig)
      .where(eq(schemaConfig.jenisId, id))
      .orderBy(asc(schemaConfig.urutan));

    return { jenis, schema };
  } catch (error) {
    console.error(`Gagal mengambil detail jenis arsip ${id}:`, error);
    return { jenis: null, schema: [] };
  }
}

/* =========================
   SAVE
========================= */

export async function saveJenisArsip(prevState: any, formData: FormData) {
  const id = formData.get("id");
  const namaJenis = formData.get("nama_jenis") as string;
  const prefixKode = formData.get("prefix_kode") as string;
  const rawSchema = formData.get("schema_json") as string;
  const deskripsi = formData.get("deskripsi") as string;

  const uiSchemaInfo = JSON.parse(rawSchema);
  const namaTabel = generateSafeTableName(namaJenis);

  try {
    /* =====================
       EDIT MODE
    ===================== */
    if (id) {
      const jenisId = Number(id);

      db.transaction((tx) => {
        tx.update(jenisArsip)
          .set({ namaJenis, prefixKode, deskripsi })
          .where(eq(jenisArsip.id, jenisId))
          .run();

        tx.delete(schemaConfig)
          .where(eq(schemaConfig.jenisId, jenisId))
          .run();

        for (const [index, field] of uiSchemaInfo.entries()) {
          tx.insert(schemaConfig).values({
            jenisId: jenisId,
            labelKolom: field.label,
            namaKolom: field.name || generateColumnName(field.label),
            tipeData: field.type || "TEXT",
            isRequired: field.required ? true : false,
            urutan: index + 1,
          }).run();
        }
      });

      revalidatePath("/arsip/jenis");
      return { success: true, message: "Konfigurasi berhasil diperbarui." };
    }

    /* =====================
       INSERT BARU
    ===================== */

    const existingTable = db.get(
      sql`SELECT name FROM sqlite_master WHERE type='table' AND name=${namaTabel}`
    );

    if (existingTable) {
      return { success: false, message: `Tabel '${namaTabel}' sudah ada.` };
    }

    db.transaction((tx) => {

      // Insert header
      const result = tx.insert(jenisArsip)
        .values({
          namaJenis,
          namaTabel,
          prefixKode,
          deskripsi
        })
        .run();

      const newJenisId = Number(result.lastInsertRowid);

      // Definisi kolom fisik
      const columnDefinitions: string[] = [];

      // System columns
      columnDefinitions.push(`id INTEGER PRIMARY KEY AUTOINCREMENT`);
      columnDefinitions.push(`nomor_urut_internal INTEGER NOT NULL`);
      columnDefinitions.push(`prefix TEXT NOT NULL DEFAULT ''`);
      columnDefinitions.push(`nomor_arsip TEXT NOT NULL DEFAULT ''`);
      columnDefinitions.push(`created_at DATETIME DEFAULT CURRENT_TIMESTAMP`);
      columnDefinitions.push(`created_by INTEGER`);

      // Loop schema - User defined columns
      // SEMUA KOLOM DIBUAT NOT NULL DENGAN DEFAULT VALUE
      for (const [index, field] of uiSchemaInfo.entries()) {
        const colName = generateColumnName(field.label);
        const colType = field.type === "number" ? "INTEGER" : "TEXT";
        
        // Tambahkan NOT NULL dengan DEFAULT
        const defaultVal = colType === "INTEGER" ? "0" : "''";
        columnDefinitions.push(`${colName} ${colType} NOT NULL DEFAULT ${defaultVal}`);

        tx.insert(schemaConfig).values({
          jenisId: newJenisId,
          namaKolom: colName,
          labelKolom: field.label,
          tipeData: colType,
          isRequired: field.required || false,
          isVisibleList: true,
          urutan: index + 1,
        }).run();
      }

      // CREATE TABLE
      const createTableQuery =
        `CREATE TABLE ${namaTabel} (${columnDefinitions.join(", ")})`;

      tx.run(sql.raw(createTableQuery));

      // INDEX untuk prefix dan nomor_arsip
      tx.run(
        sql.raw(`CREATE INDEX idx_${namaTabel}_prefix ON ${namaTabel}(prefix)`)
      );
      tx.run(
        sql.raw(`CREATE INDEX idx_${namaTabel}_nomor ON ${namaTabel}(nomor_arsip)`)
      );
      tx.run(
        sql.raw(`CREATE INDEX idx_${namaTabel}_internal ON ${namaTabel}(nomor_urut_internal)`)
      );
    });

    revalidatePath("/arsip/jenis");

    return {
      success: true,
      message: "Jenis arsip dan tabel database berhasil dibuat.",
    };

  } catch (error: any) {
    console.error("Gagal menyimpan jenis arsip:", error);

    if (error.message?.includes("UNIQUE")) {
      return {
        success: false,
        message: "Nama jenis / prefix sudah digunakan.",
      };
    }

    return {
      success: false,
      message: "Terjadi kesalahan sistem: " + error.message,
    };
  }
}

/* =========================
   DELETE
========================= */

export async function deleteJenisArsip(id: number) {
  try {
    const jenis = await db.query.jenisArsip.findFirst({
      where: eq(jenisArsip.id, id),
      columns: { namaTabel: true }
    });

    if (!jenis) {
      return { success: false, message: "Data tidak ditemukan" };
    }

    db.transaction((tx) => {

      tx.delete(schemaConfig)
        .where(eq(schemaConfig.jenisId, id))
        .run();

      tx.delete(jenisArsip)
        .where(eq(jenisArsip.id, id))
        .run();

      tx.run(sql.raw(`DROP TABLE IF EXISTS ${jenis.namaTabel}`));
    });

    revalidatePath("/arsip/jenis");

    return {
      success: true,
      message: "Jenis arsip dan data terkait berhasil dihapus.",
    };

  } catch (error) {
    console.error("Gagal menghapus jenis arsip:", error);

    return {
      success: false,
      message: "Gagal menghapus data.",
    };
  }
}
